import { Component, OnInit , ElementRef, Inject} from '@angular/core';
import { Router } from '@angular/router';
import { Mobile } from '../interfaces';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { MatDialog, MatDialogConfig } from "@angular/material";
import {AddressdetComponent } from '../addressdet/addressdet.component';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  public issue: any;
  public model: any;
  public price: any

  fcmodels = new FormControl();
  filteredmobiles: Observable<Mobile[]>;

  mobiles: Mobile[] = [
    {
      models: 'IPHONE',
      issues: '2.978M',
      photo: 'https://www.ncboostmobile.com/find-your-new-phone/iphone-6'
    },
    {
      models: 'LENOVO',
      issues: '2.978M',
      photo: 'https://www.ncboostmobile.com/find-your-new-phone/iphone-6'
    },
    {
      models: 'SAMSUNG',
      issues: '2.978M',
      photo: 'https://www.ncboostmobile.com/find-your-new-phone/iphone-6'
    },
    {
      models: 'ONE PLUS',
      issues: '2.978M',
      photo: 'https://www.ncboostmobile.com/find-your-new-phone/iphone-6'
    }
  ];

  constructor(private router: Router, public element: ElementRef, 
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<OrderComponent>,
    @Inject(MAT_DIALOG_DATA) data) {


  }

  ngOnInit() {
    this.issue = localStorage.getItem('issue');
    this.model = localStorage.getItem('model');
    this.price = localStorage.getItem('price');

    this.filteredmobiles = this.fcmodels.valueChanges
      .pipe(
        startWith<string | Mobile>(''),
        map(value => typeof value === 'string' ? value : value.models),
        map(state => state ? this._filterStates(state) : this.mobiles.slice())
      );
  }

  PlaceOrder() {
    // alert("Your Order has been placed successfully");
    alert("Please enter the shipping details");
    // this.dialogRef.close();
    if (!localStorage.getItem('session')) {
      // this.router.navigateByUrl('/login')
   
     

    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.data = {
      id: 1,
      title: 'You have logged out!'
  };

    this.dialog.open(AddressdetComponent, dialogConfig);

  }

  
  Cancel() {
    // this.router.navigateByUrl('/tiles')
    location.reload(false);
    this.dialogRef.close();

  }

  private _filterStates(value: string): Mobile[] {
    const filterValue = value.toLowerCase();

    return this.mobiles.filter(state => state.models.toLowerCase().indexOf(filterValue) === 0);
  }

  displayFn(user: Mobile){
    return  user.models ;
  }
}


