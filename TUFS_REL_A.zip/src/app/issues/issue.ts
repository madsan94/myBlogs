export interface models{
    device:String
    }

