import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderComponent } from './order/order.component'
import { LtRepairComponent } from './repairslt/repairslt.component';
import { RepairsComponent } from './repairs/repairs.component';
import { OtpComponent } from './otp/otp.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { IssuesComponent } from './issues/issues.component';
import { DropDownComponent } from './drop-down/drop-down.component';
import {TilesComponent } from './tiles/tiles.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ImagebarComponent} from './imagebar/imagebar.component';
import { HomeComponent } from './home/home.component';
const routes: Routes = [

  { path: '*', redirectTo: 'signup' },
  { path: '', component: TilesComponent },
  // { path: 'issue', component: IssuesComponent },
  { path: 'order', component: OrderComponent },
  { path: 'signout', component: DropDownComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { path: 'otp', component: OtpComponent },
  { path: 'repairs', component: RepairsComponent },
  { path: 'lt-repair', component: LtRepairComponent },
  { path: 'tiles', component: TilesComponent},
  { path: 'navbar', component: NavbarComponent},
  { path: 'imagebar', component: ImagebarComponent},
  { path: 'home', component: HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
