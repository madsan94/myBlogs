export interface otp{
    number:String
}