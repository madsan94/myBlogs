export interface otpV{
    number:String,
    otp:String
}