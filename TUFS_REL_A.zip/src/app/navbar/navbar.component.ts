import { Component, OnInit, ElementRef } from '@angular/core';
import { Injectable } from '@angular/core';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';
import { RestService } from '../rest.service'
//import { issue } from './issue'
//import { models } from './issue'
import { GrdFilterPipe } from '../grd-filter.pipe';
import { MatDialog, MatDialogConfig } from "@angular/material";
import {OrderComponent } from '../order/order.component';

import { Router } from '@angular/router'

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  animations: [

    trigger('listAnimation', [
      transition('* => *', [

        query(':enter', style({ opacity: 0 }), { optional: true }),

        query(':enter', stagger('300ms', [
          animate('1s ease-in', keyframes([
            style({ opacity: 0, transform: 'translateY(-75%)', offset: 0 }),
            style({ opacity: .5, transform: 'translateY(35px)', offset: 0.3 }),
            style({ opacity: 1, transform: 'translateY(0)', offset: 1.0 }),
          ]))]), { optional: true }),
        query('.models', stagger('300ms', [
          animate('1s ease-in', keyframes([
            style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
            style({ opacity: .5, transform: 'translateY(35px)', offset: 0.3 }),
            style({ opacity: 0, transform: 'translateY(-75%)', offset: 1.0 }),
          ]))]), { optional: true })
      ])
    ])

  ]
})
@Injectable()


export class NavbarComponent implements OnInit {

  // nameArr : string[] =  ['issue1', 'issue2', 'issue3', 'issue4', 'issue5'];


  options: string[] = [
    "ISSUE1",
    "ISSUE2",
    "ISSUE3",
    "ISSUE4",
    "ISSUE5",
    "ISSUE6",
    "ISSUE7",
    "ISSUE8",
    "ISSUE9",
    "ISSUE10",
    "ISSUE11",
    "ISSUE12",
    "ISSUE13",
    "ISSUE14",
    "ISSUE15",
    "ISSUE16",
    "ISSUE17",
    "ISSUE18",
    "ISSUE19",
    "ISSUE20",
    "ISSUE21",
    "ISSUE22",

  ];

  public searchText: any;
  public data: any;
  public issue: any;
  public model: any;
  public price: any = "200";
  items: string[] = [
    "LENOVO",
    "HP",
    "DELL",
    "APPLE",
    "ASUS",
    "ACER",
    "HCL",
    "IBM",
    "GOOGLE",
    "IBALL",
    "RDP",
    "GIGABYTE",
    "LG",
    "MICROMAX",
    "MICROSOFT",
    "SAMSUNG",
    "VAIO",
    "XIAOMI",
    "COMPAQ",
    "WIPRO"
  ];
  items_m: string[] = [
    "LENOVO",
    "HP",
    "DELL",
    "APPLE",
    "ASUS",
    "ACER",
    "HCL",
    "IBM",
    "GOOGLE",
    "IBALL",
    "RDP",
    "GIGABYTE",
    "LG",
    "MICROMAX",
    "MICROSOFT",
    "SAMSUNG",
    "VAIO",
    "XIAOMI",
    "COMPAQ",
    "WIPRO"
  ];


  flag: boolean = true;
  flag_model: boolean = false;
  flag_price: boolean = false;

  get numImages(): number {
    return this.element.nativeElement.querySelectorAll('img').length;
  }

  // numArr = Array.from(Array(22), (_, x) => x);

  constructor(public element: ElementRef, private restservice: RestService, private router: Router, 
    private dialog: MatDialog) {

    const models: any = { "device": "Laptop" }

  }

  ngOnInit() {
    localStorage.setItem('price', this.price)
  }

  ShowModels(i) {
    var issue = this.items[i]
    this.flag_model = true;
    this.flag = false;
    // localStorage.setItem('issue', this.items[i].issue);
    this.issue = localStorage.getItem('issue')

  }


  ShowPrice(i) {
    this.flag_model = false;

    localStorage.setItem('model', this.items_m[i]);
    this.model = (localStorage.getItem('model'))
    this.price = localStorage.getItem('price')
    this.router.navigateByUrl('/order')
  }

  PlaceOrder() {
    this.router.navigateByUrl('/login')
  }

  OpenDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.data = {
      id: 1,
      title: 'You have logged out!'
  };

    this.dialog.open(OrderComponent, dialogConfig);

  }
}


