
import { Component, OnInit, ElementRef, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile } from '../interfaces';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { MatDialog, MatDialogConfig } from "@angular/material";


@Component({
  selector: 'app-addressdet',
  templateUrl: './addressdet.component.html',
  styleUrls: ['./addressdet.component.css']
})
export class AddressdetComponent implements OnInit {

  constructor(private router: Router, public element: ElementRef,
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<AddressdetComponent>,
    @Inject(MAT_DIALOG_DATA) data) { }

  ngOnInit() {
  }

  ConfirmOrder() {
    alert("Your Order has been placed successfully");

    // this.dialogRef.close();
    if (!localStorage.getItem('session')) {
      this.router.navigateByUrl('/login')
    }

    location.reload(true)
    // this.router.navigateByUrl('/login')
  }
}
