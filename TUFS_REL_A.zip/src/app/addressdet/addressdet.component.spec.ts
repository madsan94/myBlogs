import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressdetComponent } from './addressdet.component';

describe('AddressdetComponent', () => {
  let component: AddressdetComponent;
  let fixture: ComponentFixture<AddressdetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressdetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressdetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
