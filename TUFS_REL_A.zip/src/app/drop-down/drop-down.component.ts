import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router'

@Component({
  selector: 'app-drop-down',
  templateUrl: './drop-down.component.html',
  styleUrls: ['./drop-down.component.css']
})
export class DropDownComponent implements OnInit {

  constructor(private router: Router, public dialog: MatDialog) { }

  // openDialog(): void {
  //   const dialogRef = this.dialog.open(DropDownComponent, {
  //     width: '250px',
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log('The dialog was closed');
  //   });
  // }


  ngOnInit() {
    localStorage.removeItem('session');
    alert("You have Logged Out")
  }
  onSubmit() {
    this.router.navigateByUrl('issue')

  }
}
