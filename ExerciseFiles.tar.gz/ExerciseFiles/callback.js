//Blocking Code Example
//We are trying here to perform an I/O operation.

//Normal Code

var fs=require("fs")
var data=fs.readFileSync('file.txt')

console.log(data.toString())
console.log("End of Program")



//Callback Code 

fs.readFile('file.txt',function(error,data){
    if(error)
    console.log(error)
    else
    console.log(data.toString())
})

console.log("End of Program")