var express=require('express')
var pg=require('pg')
var app=express()

//Set View Engine
app.set('view-engine','jade')

//Creating Postgre Pool
var Pool=pg.Pool

var pool =new Pool({
    user:'me',
    host:'localhost',
    password:'onlyme',
    database:'api',
    port:'5432'
})





app.get('/',(req,res)=>{
    res.render('home.jade')
})

app.get('/users',(req,res)=>{
    pool.query('SELECT * from users ORDER BY id ASC',(err,result)=>{
        if(err)
        console.log(err)
        console.log(result.rows)
        res.render('UserList.jade',{users:result.rows})
    })
})

app.listen('8000','0.0.0.0',()=>{
    console.log("We are ready to render jade Pages at 8000")
    pool.query('SELECT * from users ORDER BY id ASC',(err,result)=>{
        if(err)
        console.log('Error',err)
        console.log(result.rows[0].name)})
})