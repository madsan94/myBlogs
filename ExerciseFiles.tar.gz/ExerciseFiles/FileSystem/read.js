var fs=require('fs')

fs.readFile('test','utf-8',function(err,data){
    if(err)
    console.log(err)
    console.log(data)
})


var data=fs.readFileSync('test','utf-8')
console.log(data)