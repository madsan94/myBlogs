var fs=require('fs')

fs.appendFile('test','Hello World Append',(err)=>{
    if(err)
    console.log(err)
    console.log("File Appended Successfully")
})