var fs=require('fs')

fs.writeFile('test','Hello World',(err)=>{
    if(err)
    console.log(err)
    console.log("File Written Successfully")
})


var data=fs.writeFileSync('test','Hello Synchronous')
console.log(data)

