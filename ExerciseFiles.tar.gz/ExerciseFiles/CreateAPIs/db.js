var pg=require('pg')

var Pool=pg.Pool;

var pool=new Pool({
    user:'me',
    host:'localhost',
    database:'api',
    password:'onlyme',
    port:'5432'
})


var getUsers= (req,res)=>{
    pool.query('SELECT * from users ORDER BY id ASC',(err,result)=>{
        if(err){
            console.log(err)
        }
        res.status(200).json(result.rows)
    })
}


var getUserById = (req, res) => {
    var id = parseInt(req.params.id)
  
    pool.query('SELECT * FROM users WHERE id = $1', [id], (err, results) => {
      if (err) {
        console.log(err); 
      }
      res.status(200).json(results.rows)
    })
  }

var createUser = (req, res) => {
    const { name, email } = req.body
  
    pool.query('INSERT INTO users (name, email) VALUES ($1, $2)', [name, email], (err, results) => {
      if (err) {
        throw err
      }
      pool.query('SELECT max(id) from users',(error,result)=>{
          
        res.status(201).send(`User added with ID: ${result.rows[0].max}`)
      })
      
    })
  }


  var updateUser = (req, res) => {
    var id = parseInt(req.params.id)
    var { name, email } = req.body
  
    pool.query(
      'UPDATE users SET name = $1, email = $2 WHERE id = $3',
      [name, email, id],
      (err, results) => {
        if (err) {
          throw err
        }
        res.status(200).send(`User modified with ID: ${id}`)
      }
    )
  }

  var deleteUser = (req, res) => {
    var id = parseInt(req.params.id)
  
    pool.query('DELETE FROM users WHERE id = $1', [id], (err, results) => {
      if (err) {
        throw err
      }
      res.status(200).send(`User deleted with ID: ${id}`)
    })
  }


  module.exports = {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
  }
