var express = require('express')
var bodyParser=require('body-parser')
var db = require('./db')

var app=express()

//Body Parser
app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/',(request,response)=>{
response.json(
    {'message':'HOME GET response'}
)
})

app.get('/users', db.getUsers)
app.get('/users/:id', db.getUserById)
app.post('/users', db.createUser)
app.put('/users/:id', db.updateUser)
app.delete('/users/:id', db.deleteUser)

app.listen("8000","0.0.0.0",()=>{
    console.log(" We are live at 8000")
})