//We will be creating a simple server here using express
//Install express : npm install express
//First we need to install and import express using require
var express=require('express')

//We will then initialise the app on which we will be making the server
var app=express();

//Initializing the port, where the server will listen
var port=8000

//We will be using 'ejs' as the engine for the app which compiles with the express view system
//for static caching of intermediate JS
app.engine('html',require('ejs').renderFile);


//Creating the server to listen to our designated port
//0.0.0.0 is our localhost

//We have to add require so that node js can find our location to the routes page
require('./app/routes')(app);
app.listen(port,"0.0.0.0",function(){
    console.log("We are live on"+port);
})