//We will export the module here to define all our routes here
//Simple way of doing that is

module.exports=function(app){

// To test if our routes and server are working, we will create a small html page
    app.get('/',(request,response)=>{
        response.render('index.html')
    })
}
